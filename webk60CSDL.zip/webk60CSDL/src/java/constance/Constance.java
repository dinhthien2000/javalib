/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package constance;

/**
 *
 * @author Admin
 */
public class Constance {
      public static final String DB_URL = "jdbc:mysql://localhost:3307/qlnhansu?characterEncoding=utf8";
     public static final String USER_NAME = "root";
     public static final String PASSWORD = "";
}
